/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package awrnndfinalproject;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.stage.FileChooser;

/**
 * FXML Controller class
 *
 * @author Alec Richardson <your.name at your.org>
 */
public class Page2Controller extends Switchable implements Initializable {
    Score score;
//    
//     @FXML
//    public void handleSave(ActionEvent event) {
//        person = createPersonFromFormData(); 
//        
//        if(person == null){
//            return; 
//        }
//        
//        FileChooser fileChooser = new FileChooser();
//        File file = fileChooser.showSaveDialog(stage);
//        if (file != null) {
//            
//            try {
//                FileOutputStream fileOut = new FileOutputStream(file.getPath());
//                ObjectOutputStream out = new ObjectOutputStream(fileOut); 
//                
//                out.writeObject(person);
//                out.close(); 
//                fileOut.close(); 
//                
//            } catch (FileNotFoundException ex) {
//                String message = "File not found exception occured while saving to " + file.getPath(); 
//                displayExceptionAlert(message, ex); 
//                
//            } catch (IOException ex) {
//                String message = "IOException occured while saving to " + file.getPath();
//                displayExceptionAlert(message, ex);
//                
//            }
//        }        
//    }
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
}
